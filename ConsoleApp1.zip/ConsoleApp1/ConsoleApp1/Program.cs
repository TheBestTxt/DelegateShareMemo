﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ConsoleApp1
{
    class Program
    {
        private delegate void VoidDeletage(int a, int b);

        static void Main(string[] args)
        {
            VoidDeletage voidDeletage = new VoidDeletage(Add);
            Console.WriteLine("委托是否为Class:" + voidDeletage.GetType().IsClass);
            Console.ReadLine();
            voidDeletage(1, 1);
            Console.ReadLine();

            voidDeletage = (a, b) => Console.WriteLine($"使用lambda表达式定义delegate：{a}+{b}={a + b}");
            voidDeletage(2, 2);
            Console.ReadLine();

            var demo = new DelegateDemo(new List<int>() { 1, 2, 3, 4, 5, 6, 7, 8, 9 });
            Console.WriteLine($"使用Linq求和：{demo.Excute(a => a.Sum())}");
            Console.ReadKey();
            Console.WriteLine($@"使用lambda求和：{demo.Excute(a =>
            {
                var sum = 0;
                foreach (var item in a)
                {
                    sum += item;
                }
                return sum;
            })}");
            Console.ReadLine();

            Action<int, int> add = new Action<int, int>(Add);
            add(1, 1);
            add = (a, b) => Console.WriteLine($"使用lambda表达式定义delegate：{a}+{b}={a + b}");

            Func<int, int> addSelf = new Func<int, int>(AddSelf);
            Console.WriteLine($"使用Func返回：1+1={addSelf(1)}");
        }


        private static void Add(int a, int b)
        {
            Console.WriteLine($"使用Add方法定义delegate：{a}+{b}={a + b}");
        }

        private static int AddSelf(int a)
        {
            return a + a;
        }
    }
    // https://www.cnblogs.com/jesse2013/p/expressiontree-part1.html
    // https://dotblogs.com.tw/daniel/2018/01/09/151636
    // https://dotblogs.com.tw/daniel/2017/11/21/145211
    // https://www.cnblogs.com/rush/archive/2011/04/23/delegate_event.html
}
