﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp1
{
    public class DelegateDemo
    {
        public delegate int Calculate(List<int> list);

        private List<int> _list;

        public DelegateDemo(List<int> list)
        {
            _list = list;
        }

        public int Excute(Calculate calc)
        {
            return calc(_list);
        }
    }
}
